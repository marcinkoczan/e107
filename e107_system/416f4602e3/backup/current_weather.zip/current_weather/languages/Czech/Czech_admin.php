<?php
 /**
 * Current Weather plugin for CMS e107 v2
 *
 * @author OxigenO2 (oxigen.rg@gmail.com)
 * @copyright Copyright (C) 2014 OxigenO2 
 * @license GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 * @link http://oxigen.mablog.eu/
 */
define("LAN_WEATHER_ADMIN_ADMIN_CITY",  "Město"); 
define("LAN_WEATHER_ADMIN_UNIT",  "Jednotka teploty");
define("LAN_WEATHER_ADMIN_COLOR", "Styl ikon");
define("LAN_WEATHER_ADMIN_DETAILS", "Zobrazit detaily");
define("LAN_WEATHER_ADMIN_COLOR_1", "Bílé");
define("LAN_WEATHER_ADMIN_COLOR_2", "Černé");
define("LAN_WEATHER_ADMIN_COLOR_3", "Barevné"); 
define("LAN_WEATHER_ADMIN_LINK", "Ukázat odkaz - OpenWeatherMap");
define("LAN_WEATHER_ADMIN_LINK_H", "Pozor na licenci, více v podpoře.");

?>