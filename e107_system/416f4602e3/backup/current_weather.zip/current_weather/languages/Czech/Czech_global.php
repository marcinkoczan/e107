<?php
/**
 * Current Weather plugin for CMS e107 v2
 *
 * @author OxigenO2 (oxigen.rg@gmail.com)
 * @copyright Copyright (C) 2014 OxigenO2 
 * @license GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 * @link http://oxigen.mablog.eu/
 */
define("LAN_WEATHER_MENU_NAME",  "Aktuální počasí");
define("LAN_WEATHER_MENU_DESC",  "Zobrazí aktuální počasí (teplotu, vítr, vlhkost, východ a západ slunce) pro zvolené město.");
define("LAN_WEATHER_MENU_SUMM",  "Počasí ve městě.");

?>