<?php
/**
 * Current Weather plugin for CMS e107 v2
 *
 * @author OxigenO2 (oxigen.rg@gmail.com)
 * @copyright Copyright (C) 2014 OxigenO2 
 * @license GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 * @link http://oxigen.mablog.eu/
 */
define("LAN_WEATHER_MENU_NAME",  "Current Weather");
define("LAN_WEATHER_MENU_DESC",  "Displays city weather on the menu.");
define("LAN_WEATHER_MENU_SUMM",  "Displays city weather.");

?>