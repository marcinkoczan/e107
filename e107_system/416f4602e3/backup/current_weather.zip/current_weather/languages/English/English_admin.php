<?php
 /**
 * Current Weather plugin for CMS e107 v2
 *
 * @author OxigenO2 (oxigen.rg@gmail.com)
 * @copyright Copyright (C) 2014 OxigenO2 
 * @license GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 * @link http://oxigen.mablog.eu/
 */
define("LAN_WEATHER_ADMIN_ADMIN_CITY",  "City"); 
define("LAN_WEATHER_ADMIN_UNIT",  "Temperature unit");
define("LAN_WEATHER_ADMIN_COLOR", "Style icons");
define("LAN_WEATHER_ADMIN_DETAILS", "Show details");
define("LAN_WEATHER_ADMIN_COLOR_1", "White");
define("LAN_WEATHER_ADMIN_COLOR_2", "Black");
define("LAN_WEATHER_ADMIN_COLOR_3", "Color");
define("LAN_WEATHER_ADMIN_LINK", "Show link - OpenWeatherMap");
define("LAN_WEATHER_ADMIN_LINK_H", "Comply licenses!");

?>