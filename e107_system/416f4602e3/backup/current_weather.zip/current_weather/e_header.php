<?php
if(USER_AREA)
{
	e107::css('current_weather','css/current_weather.css');
}
?>