*****************************************************************
 Tema/Theme       : bread_of_life
 Autore/Author    : Alf - e107wORks
 Versione/Version : 1.0
 Data/Date        : 1 dic 2010
 Copyright        : � e107wORks
 Licenza/License  : Creative Commons http://creativecommons.org/licenses/by-nc-sa/3.0/deed.it
 Website          : www.e107works.org
******************************************************************

[ITALIANO]

bread_of_life �  un tema molto facile da usare, praticamente "plug and play" , che richiede pochissimi passaggi per la sua personalizzazione e adattamento al proprio sito.
Sar� infatti sufficiente sostituire l'immagine di background in testata (rispettandone forma e dimensioni) e configurare il menu dal pannello di amministrazione di e107, oltre che ad assegnare i blocchi menu alle quattro aree disponibili.

Con due blocchi menu laterali, � prevista un'area banner centrale in alto ed in basso, nell'area contenuti. 

Il menu di navigazione � gestito dal tema e legge i links del sito dal database, mostrandone un numero massimo di 7.

INSTALLAZIONE:

1) Scompattare il file bread_of_life.zip ;
2) caricare la cartella (scompattata) bread_of_life nella cartella e107_themes;
3) da gestione temi di e107 impostare bread_of_life come tema del sito
4) Configurare i link del menu dal pannello Admin di e107;
5) Assegnare i blocchi menu desiderati.


enjoy
Alf 



[ENGLISH]

bread_of_life is a "plug and play" theme, which requires very few steps for its customization and adaptation to your site.
It would indeed be sufficient to replace the background image in the header and configure the menu from the admin panel of e107, as well as to allocate the blocks menu to the four available areas.

With two block side menu, it's planned a central area banner at the top and at the bottom, in the content area.

Navigation is handled by the theme and read the links of the site  from the database, showing a maximum of 7, both in the header and the footer.


INSTALLATION:

1) unzip bread_of_life.zip file;
2) upload the folder (unzipped) bread_of_life in e107_themes folder;
3) from theme management of e107 set bread_of_life as the theme of the site;
4) Set the menu link from e107 Admin panel;
5) Assign the blocks menu you want.


enjoy
Alf 