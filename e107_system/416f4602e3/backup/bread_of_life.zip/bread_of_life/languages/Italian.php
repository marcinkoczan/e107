<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|
|	©Steve Dunstan 2001-2005
|	http://e107.org
|	jalist@e107.org
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
|
|
|   Tema bread_of_life
|   by Alf - http://www.e107works.org
|   Released under the terms and conditions of the
|   Creative Commons "Attribution-Noncommercial-Share Alike 3.0"
|   http://creativecommons.org/licenses/by-nc-sa/3.0/
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "Tema <strong>bread_of_life</strong> by <strong>e107wORks</strong>");
define("LAN_THEME_3", "Commenti ");
define("LAN_THEME_4", "... Leggi tutto");
define("LAN_THEME_7", "da ");
define("LAN_THEME_8", "il:");

define("COMLAN_326", "Replica");



?>
