=============================================================================================

This plugin allows you to Show a slideshow of all your Panoramio photos in e107 menu on your site.
Edit and add your Panoramio user number in g1.htm. (I've put in my panaromio user number).
You can select a tag for this slideshow please add "&tag=yourtag" after "&order=date_desc".
You can edit Delay, in seconds, for advancing automatically to the next photo in "&delay=6.5"
This slideshow Show the photos in descending date order, that is, from newest to oldest, if you want show in ascending date order you must delete "&order=date_desc".
For more information use this link "http://www.panoramio.com/api/widget/api.html#templates"

=====================================================================================================
To Do...
=====================================================================================================

Open g1.htm

You need to change Panoramio user number to your number user in "user=1265204".
