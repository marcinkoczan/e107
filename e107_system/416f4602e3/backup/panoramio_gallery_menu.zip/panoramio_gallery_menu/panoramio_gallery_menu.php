<?
/*
+---------------------------------------------------------------+ 
| Panoramio gallery menu v1.0 - by Mahmood Safavi (info@sabaa.com) 
| 
| For the e107 website system 
| ©Steve Dunstan 2001-2002 
| http://e107.org 
| jalist@e107.org 
| 
| Released under the terms and conditions of the 
| GNU General Public License (http://gnu.org). 
| 
+---------------------------------------------------------------+ 
*/

if (!defined('e107_INIT')) { exit; }
$lan_file = e_PLUGIN."panoramio_gallery_menu/languages/".e_LANGUAGE.".php";
include(file_exists($lan_file) ? $lan_file : e_PLUGIN."panoramio_gallery_menu/languages/English.php");


$text = "<p align='center'></p><p><iframe id='datamain' align='center' src= '".e_PLUGIN."panoramio_gallery_menu/g1.htm' width=170 height=170 marginwidth=0 marginheight=0 hspace=0 vspace=0 frameborder=0 scrolling=no></iframe></p>";
$ns -> tablerender(PANORAMIO_LAN_1, $text);
?>