<?php
/*
+---------------------------------------------------------------+ 
| Panoramio gallery menu v1.0 - by Mahmood Safavi (info@sabaa.com) 
| 
| For the e107 website system 
| �Steve Dunstan 2001-2002 
| http://e107.org 
| jalist@e107.org 
| 
| Released under the terms and conditions of the 
| GNU General Public License (http://gnu.org). 
| 
+---------------------------------------------------------------+ 
*/
if (!defined('e107_INIT')) { exit; }

$eplug_name = "Panoramio gallery menu";
$eplug_version = "1.0";
$eplug_author = "Mahmood Safavi";
$eplug_url = "http://www.sabaa.com";
$eplug_email = "info@sabaa.com";
$eplug_description = "This plugin Show a slideshow of all your Panoramio photos in e107 menu.";
$eplug_compatible = "e107v7+";
$eplug_compliant = false;
$eplug_readme = "readme.txt";

$eplug_folder = "panoramio_gallery_menu";
$eplug_menu_name = "panoramio_gallery_menu";
$eplug_conffile = "";
$eplug_module = false;
$eplug_icon = $eplug_folder."/images/panoramio.png";
$eplug_icon_small = $eplug_folder."/images/panoramio.png";
$eplug_caption = "Please read readme.txt";

$eplug_prefs = array(
"panoramio_gallery_menu" => "0"
);

$eplug_link = false;
$eplug_link_name = "panoramio_gallery_menu";
$eplug_link_url = e_PLUGIN.$eplug_folder."/panoramio_gallery_menu.php";
$eplug_done = "Installation Has Been Successful You must add menu";



// upgrading ... //

$upgrade_add_prefs = "";

$upgrade_remove_prefs = "";

$upgrade_alter_tables = "";

$eplug_upgrade_done = "";





?>